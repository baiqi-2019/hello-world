window.onload = function () {
    //数量加减
    var plus = document.getElementById("plus");
    var i = document.getElementById("text").value;
    var subtract = document.getElementById("subtract");
    var money = document.getElementById("money").value;
    plus.onclick = function () {
        i++;
        document.getElementById("text").value = i;
        document.getElementById("money").value = i * money;
    }
    subtract.onclick = function () {
        if (i > 0) {
            i--;
            document.getElementById("text").value = i;
            document.getElementById("money").value = i * money;
        } else {
            i = 0;
            document.getElementById("text").value = i;
            document.getElementById("money").value = i * money;
        }
    }
    //图片轮播
    var pics = document.getElementById("pics");
    var n = 1;
    setInterval(function () {
        if (n > 2) n = 1
        pics.innerHTML = "<img src='picture/pic(" + n + ").png' />";
        n++;
    }, 1500);
    //点击区域隐藏或显示
    var choose_lable = document.getElementById("choose_lable");
    var area_list = document.getElementById("area_list");
    choose_lable.onclick = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        if (area_list.style.display == 'none') {
            area_list.style.display = 'block';
        } else {
            area_list.style.display = 'none';
        }
    }
    document.onclick = function () {
        area_list.style.display = 'none';
    }
    //鼠标悬停下拉菜单1
    var a_mydd = document.getElementById("a_mydd");
    var mydd_list = document.getElementById("mydd_list");
    var lis = mydd_list.getElementsByTagName('li');
    a_mydd.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        mydd_list.style.display = 'block';
    }
    //鼠标划过背景改变
    for (var i = 0, l = lis.length; i < l; i++) {
        lis[i].onmouseover = function (e) {
            e = e || window.event;
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
            this.style.background = '#e6e6e6';
        }
        lis[i].onmouseout = function () {
            this.style.background = '#FFF';
        }
    }
    //鼠标移开菜单收起
    document.onmouseover = function () {
        mydd_list.style.display = 'none';
        gouwu_list.style.display = 'none';
        qycg_list.style.display = 'none';
        khfw_list.style.display = 'none';
    }
    //鼠标悬停下拉菜单2
    var a_gouwu = document.getElementById("a_gouwu");
    var gouwu_list = document.getElementById("gouwu_list");
    var lis2 = gouwu_list.getElementsByTagName('li');
    a_gouwu.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        gouwu_list.style.display = 'block';
    }
    //鼠标划过背景改变
    for (var i = 0, l = lis2.length; i < l; i++) {
        lis2[i].onmouseover = function (e) {
            e = e || window.event;
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
            this.style.background = '#e6e6e6';
        }
        lis2[i].onmouseout = function () {
            this.style.background = '#FFF';
        }
    }
    //鼠标悬停下拉菜单3
    var a_qycg = document.getElementById("a_qycg");
    var qycg_list = document.getElementById("qycg_list");
    var lis3 = qycg_list.getElementsByTagName('li');
    a_qycg.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        qycg_list.style.display = 'block';
    }
    //鼠标划过背景改变
    for (var i = 0, l = lis3.length; i < l; i++) {
        lis3[i].onmouseover = function (e) {
            e = e || window.event;
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
            this.style.background = '#e6e6e6';
        }
        lis3[i].onmouseout = function () {
            this.style.background = '#FFF';
        }
    }
    //鼠标悬停下拉菜单4
    var a_khfw = document.getElementById("a_khfw");
    var khfw_list = document.getElementById("khfw_list");
    var lis4 = khfw_list.getElementsByTagName('li');
    a_khfw.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        khfw_list.style.display = 'block';
    }
    //鼠标划过背景改变
    for (var i = 0, l = lis4.length; i < l; i++) {
        lis4[i].onmouseover = function (e) {
            e = e || window.event;
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
            this.style.background = '#e6e6e6';
        }
        lis4[i].onmouseout = function () {
            this.style.background = '#FFF';
        }
    }

}

