window.onload = function () {
    var pics = document.getElementById("pics");
    var n = 1;
    setInterval(function () {
        if (n > 8) n = 1
        pics.innerHTML = "<img src='picture/big_pic_(" + n + ").png' />";
        n++;
    }, 1500);

    var roll_aa_pics = document.getElementById("roll_aa_pics");
    var j = 1;
    setInterval(function () {
        if (j > 3) j = 1
        roll_aa_pics.innerHTML = "<img src='picture/roll_aa_" + j + ".png' />";
        j++;
    }, 1500);

    var roll_bb_pics = document.getElementById("roll_bb_pics");
    var m = 1;
    setInterval(function () {
        if (m > 2) m = 1
        roll_bb_pics.innerHTML = "<img src='picture/roll_bb_" + m + ".png' />";
        m++;
    }, 1500);
    //鼠标悬停改变图片内容
    var item_1 = document.getElementById("item_1");
    item_1.onmouseenter = function(){
        item_1.children[0].setAttribute('src','picture/active_pic_' + 2 + '.png' )
    }
    item_1.onmouseleave = function(){
        item_1.children[0].setAttribute('src','picture/active_pic_' + 1 + '.png' )
    }

    var item_2 = document.getElementById("item_2");
    item_2.onmouseenter = function(){
        item_2.children[0].setAttribute('src','picture/active_pic_' + 4 + '.png' )
    }
    item_2.onmouseleave = function(){
        item_2.children[0].setAttribute('src','picture/active_pic_' + 3 + '.png' )
    }

    var item_3 = document.getElementById("item_3");
    item_3.onmouseenter = function(){
        item_3.children[0].setAttribute('src','picture/active_pic_' + 6 + '.png' )
    }
    item_3.onmouseleave = function(){
        item_3.children[0].setAttribute('src','picture/active_pic_' + 5 + '.png' )
    }

    var item_4 = document.getElementById("item_4");
    item_4.onmouseenter = function(){
        item_4.children[0].setAttribute('src','picture/active_pic_' + 8 + '.png' )
    }
    item_4.onmouseleave = function(){
        item_4.children[0].setAttribute('src','picture/active_pic_' + 7 + '.png' )
    }
    //倒计时
    var myVar;
    myVar = setInterval(countTime,1000);
    function countTime(){
        var date = new Date();
        var now = date.getTime();
        var str = "2019/9/10 00:00:00";
        var endDate = new Date(str);
        var end = endDate.getTime();
        var leftTime = end-now;
        var d,h,m,s;
        if (leftTime>=0){
            d = Math.floor(leftTime/1000/60/60/24);
            h = Math.floor(leftTime/1000/60/60%24);
            m = Math.floor(leftTime/1000/60%60);
            s = Math.floor(leftTime/1000%60);
        }
        document.getElementById("_d").innerHTML=d +"天";
        document.getElementById("_h").innerHTML=h +"时";
        document.getElementById("_m").innerHTML=m +"分";
        document.getElementById("_s").innerHTML=s +"秒";  
    }
 
    //鼠标悬停改变区域内容
    document.getElementsByClassName("tab_aa")[1].addEventListener('mouseover',function(e){
        if(e.target.className.indexOf('tabh')!= -1){
            var child = this.children
            for(var i = 0;i<child.length;i++){
                child[i].style.background = '#f5f5f5';
                child[i].style.border = '0';
            }
            e.target.style.background = '#fff';
            e.target.style.border = '2px solid #000';
            e.target.style.borderBottom = '2px solid #fff';
        }
    });
    //鼠标划过改变块内容
    var bb_1 =  document.getElementById("bb_1");
    var bb_2 =  document.getElementById("bb_2");
    var tab_bb_pics = document.getElementById("tab_bb_pics");
    bb_1.onmouseover = function(){
        bb_1.style.background ='#fff';
        tab_bb_pics.innerHTML = "<img src='picture/table_bb_"+ 1 +".png'>";
    }
    bb_1.onmouseout = function(){
        bb_1.style.background = '#f5f5f5';
    }
    bb_2.onmouseover = function(){
        bb_2.style.background ='#fff';
        tab_bb_pics.innerHTML = "<img src='picture/table_bb_"+ 2 +".png'>";
    }
    bb_2.onmouseout = function(){
        bb_2.style.background = '#f5f5f5';
    }
    //鼠标划过改变块内容
    var xxgg = document.getElementById("xxgg");
    var fwgg = document.getElementById("fwgg");
    var xxgg_tab = document.getElementById("xxgg_tab");
    var fwgg_tab = document.getElementById("fwgg_tab");
    xxgg.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        xxgg_tab.style.display = 'block';
        fwgg_tab.style.display = 'none';
        xxgg.style.background = '#fff';
        fwgg.style.background = '#f0f0f0';
    }
    fwgg.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        fwgg_tab.style.display = 'block';
        xxgg_tab.style.display = 'none';
        fwgg.style.background = '#fff';
        xxgg.style.background = '#f0f0f0';
    }
    //鼠标悬停显示右侧菜单1
    var li_lable_1 = document.getElementById("li_lable_1");
    var ddnav_sort1 = document.getElementById("ddnav_sort1");
    li_lable_1.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort1.style.display = 'block';
        li_lable_1.style.borderTop = '2px solid #ff2832';
        li_lable_1.style.borderLeft = '2px solid #ff2832';
        li_lable_1.style.borderBottom = '2px solid #ff2832';
        li_lable_1.style.borderRight = '2px solid #fff';
    }
    ddnav_sort1.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort1.style.display = 'block';
    }
    //2
    var li_lable_2 = document.getElementById("li_lable_2");
    var ddnav_sort2 = document.getElementById("ddnav_sort2");
    li_lable_2.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort2.style.display = 'block';
        li_lable_1.style.borderBottom = '2px solid #ff2832';
        li_lable_2.style.borderLeft = '2px solid #ff2832';
        li_lable_2.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort2.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort2.style.display = 'block';
    }
    //3
    var li_lable_3 = document.getElementById("li_lable_3");
    var ddnav_sort3 = document.getElementById("ddnav_sort3");
    li_lable_3.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort3.style.display = 'block';
        li_lable_2.style.borderBottom = '2px solid #ff2832';
        li_lable_3.style.borderLeft = '2px solid #ff2832';
        li_lable_3.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort3.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort3.style.display = 'block';
    }
    //4
    var li_lable_4 = document.getElementById("li_lable_4");
    var ddnav_sort4 = document.getElementById("ddnav_sort4");
    li_lable_4.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort4.style.display = 'block';
        li_lable_3.style.borderBottom = '2px solid #ff2832';
        li_lable_4.style.borderLeft = '2px solid #ff2832';
        li_lable_4.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort3.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort3.style.display = 'block';
    }
    //5
    var li_lable_5 = document.getElementById("li_lable_5");
    var ddnav_sort5 = document.getElementById("ddnav_sort5");
    li_lable_5.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort5.style.display = 'block';
        li_lable_4.style.borderBottom = '2px solid #ff2832';
        li_lable_5.style.borderLeft = '2px solid #ff2832';
        li_lable_5.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort5.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort5.style.display = 'block';
    }
    //6
    var li_lable_6 = document.getElementById("li_lable_6");
    var ddnav_sort6 = document.getElementById("ddnav_sort6");
    li_lable_6.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort6.style.display = 'block';
        li_lable_5.style.borderBottom = '2px solid #ff2832';
        li_lable_6.style.borderLeft = '2px solid #ff2832';
        li_lable_6.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort6.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort6.style.display = 'block';
    }
    //7
    var li_lable_7 = document.getElementById("li_lable_7");
    var ddnav_sort7 = document.getElementById("ddnav_sort7");
    li_lable_7.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort7.style.display = 'block';
        li_lable_6.style.borderBottom = '2px solid #ff2832';
        li_lable_7.style.borderLeft = '2px solid #ff2832';
        li_lable_7.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort7.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort7.style.display = 'block';
    }
    //8
    var li_lable_8 = document.getElementById("li_lable_8");
    var ddnav_sort8 = document.getElementById("ddnav_sort8");
    li_lable_8.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort8.style.display = 'block';
        li_lable_7.style.borderBottom = '2px solid #ff2832';
        li_lable_8.style.borderLeft = '2px solid #ff2832';
        li_lable_8.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort8.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort8.style.display = 'block';
    }
    //9
    var li_lable_9 = document.getElementById("li_lable_9");
    var ddnav_sort9 = document.getElementById("ddnav_sort9");
    li_lable_9.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort9.style.display = 'block';
        li_lable_8.style.borderBottom = '2px solid #ff2832';
        li_lable_9.style.borderLeft = '2px solid #ff2832';
        li_lable_9.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort9.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort9.style.display = 'block';
    }
    //10
    var li_lable_10 = document.getElementById("li_lable_10");
    var ddnav_sort10 = document.getElementById("ddnav_sort10");
    li_lable_10.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort10.style.display = 'block';
        li_lable_9.style.borderBottom = '2px solid #ff2832';
        li_lable_10.style.borderLeft = '2px solid #ff2832';
        li_lable_10.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort10.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort10.style.display = 'block';
    }
    //11
    var li_lable_11 = document.getElementById("li_lable_11");
    var ddnav_sort11 = document.getElementById("ddnav_sort11");
    li_lable_11.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort11.style.display = 'block';
        li_lable_10.style.borderBottom = '2px solid #ff2832';
        li_lable_11.style.borderLeft = '2px solid #ff2832';
        li_lable_11.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort11.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort11.style.display = 'block';
    }
    //12
    var li_lable_12 = document.getElementById("li_lable_12");
    var ddnav_sort12 = document.getElementById("ddnav_sort12");
    li_lable_12.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort12.style.display = 'block';
        li_lable_11.style.borderBottom = '2px solid #ff2832';
        li_lable_12.style.borderLeft = '2px solid #ff2832';
        li_lable_12.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort12.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort12.style.display = 'block';
    }
    //13
    var li_lable_13 = document.getElementById("li_lable_13");
    var ddnav_sort13 = document.getElementById("ddnav_sort13");
    li_lable_13.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort13.style.display = 'block';
        li_lable_12.style.borderBottom = '2px solid #ff2832';
        li_lable_13.style.borderLeft = '2px solid #ff2832';
        li_lable_13.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort13.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort13.style.display = 'block';
    }
    //14
    var li_lable_14 = document.getElementById("li_lable_14");
    var ddnav_sort14 = document.getElementById("ddnav_sort14");
    li_lable_14.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort14.style.display = 'block';
        li_lable_13.style.borderBottom = '2px solid #ff2832';
        li_lable_14.style.borderLeft = '2px solid #ff2832';
        li_lable_14.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort14.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort14.style.display = 'block';
    }
    //15
    var li_lable_15 = document.getElementById("li_lable_15");
    var ddnav_sort15 = document.getElementById("ddnav_sort15");
    li_lable_15.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort15.style.display = 'block';
        li_lable_14.style.borderBottom = '2px solid #ff2832';
        li_lable_15.style.borderLeft = '2px solid #ff2832';
        li_lable_15.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort15.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort15.style.display = 'block';
    }
    //16
    var li_lable_16 = document.getElementById("li_lable_16");
    var ddnav_sort16 = document.getElementById("ddnav_sort16");
    li_lable_16.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort16.style.display = 'block';
        li_lable_15.style.borderBottom = '2px solid #ff2832';
        li_lable_16.style.borderLeft = '2px solid #ff2832';
        li_lable_16.style.borderBottom = '2px solid #ff2832';
    }
    ddnav_sort16.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        ddnav_sort16.style.display = 'block';
    }
    //鼠标悬停下拉菜单1
    var a_mydd = document.getElementById("a_mydd");
    var mydd_list = document.getElementById("mydd_list");
    var lis = mydd_list.getElementsByTagName('li');
    a_mydd.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        mydd_list.style.display = 'block';
    }
    //鼠标划过背景改变
    for (var i = 0, l = lis.length; i < l; i++) {
        lis[i].onmouseover = function (e) {
            e = e || window.event;
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
            this.style.background = '#e6e6e6';
        }
        lis[i].onmouseout = function () {
            this.style.background = '#FFF';
        }
    }
    //鼠标移开菜单收起
    document.onmouseover = function () {
        mydd_list.style.display = 'none';
        gouwu_list.style.display = 'none';
        qycg_list.style.display = 'none';
        khfw_list.style.display = 'none';
        ddnav_sort1.style.display = 'none';
        ddnav_sort2.style.display = 'none';
        ddnav_sort3.style.display = 'none';
        ddnav_sort4.style.display = 'none';
        ddnav_sort5.style.display = 'none';
        ddnav_sort6.style.display = 'none';
        ddnav_sort7.style.display = 'none';
        ddnav_sort8.style.display = 'none';
        ddnav_sort9.style.display = 'none';
        ddnav_sort10.style.display = 'none';
        ddnav_sort11.style.display = 'none';
        ddnav_sort12.style.display = 'none';
        ddnav_sort13.style.display = 'none';
        ddnav_sort14.style.display = 'none';
        ddnav_sort15.style.display = 'none';
        ddnav_sort16.style.display = 'none';
        li_lable_1.style.border = '0';
        li_lable_2.style.border = '0';
        li_lable_3.style.border = '0';
        li_lable_4.style.border = '0';
        li_lable_5.style.border = '0';
        li_lable_6.style.border = '0';
        li_lable_7.style.border = '0';
        li_lable_8.style.border = '0';
        li_lable_9.style.border = '0';
        li_lable_10.style.border = '0';
        li_lable_11.style.border = '0';
        li_lable_12.style.border = '0';
        li_lable_13.style.border = '0';
        li_lable_14.style.border = '0';
        li_lable_15.style.border = '0';
        li_lable_16.style.border = '0';
    }
    //鼠标悬停下拉菜单2
    var a_gouwu = document.getElementById("a_gouwu");
    var gouwu_list = document.getElementById("gouwu_list");
    var lis2 = gouwu_list.getElementsByTagName('li');
    a_gouwu.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        gouwu_list.style.display = 'block';
    }
    //鼠标划过背景改变
    for (var i = 0, l = lis2.length; i < l; i++) {
        lis2[i].onmouseover = function (e) {
            e = e || window.event;
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
            this.style.background = '#e6e6e6';
        }
        lis2[i].onmouseout = function () {
            this.style.background = '#FFF';
        }
    }
    //鼠标悬停下拉菜单3
    var a_qycg = document.getElementById("a_qycg");
    var qycg_list = document.getElementById("qycg_list");
    var lis3 = qycg_list.getElementsByTagName('li');
    a_qycg.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        qycg_list.style.display = 'block';
    }
    //鼠标划过背景改变
    for (var i = 0, l = lis3.length; i < l; i++) {
        lis3[i].onmouseover = function (e) {
            e = e || window.event;
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
            this.style.background = '#e6e6e6';
        }
        lis3[i].onmouseout = function () {
            this.style.background = '#FFF';
        }
    }
    //鼠标悬停下拉菜单4
    var a_khfw = document.getElementById("a_khfw");
    var khfw_list = document.getElementById("khfw_list");
    var lis4 = khfw_list.getElementsByTagName('li');
    a_khfw.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        khfw_list.style.display = 'block';
    }
    //鼠标划过背景改变
    for (var i = 0, l = lis4.length; i < l; i++) {
        lis4[i].onmouseover = function (e) {
            e = e || window.event;
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
            this.style.background = '#e6e6e6';
        }
        lis4[i].onmouseout = function () {
            this.style.background = '#FFF';
        }
    }
    //回到顶部//
    var obtn = document.getElementById("btn");
    var timer = null;
    var isTop = true;
    window.onscroll = function () {
        if (!isTop) {
            clearInterval(timer);
        }
        isTop = false;
    }
    obtn.onclick = function () {
        timer = setInterval(function(){
            var osTop = document.documentElement.scrollTop || document.body.scrollTop;
            var ispeed = Math.floor(-osTop / 6);
            document.documentElement.scrollTop = document.body.scrollTop = osTop + ispeed;
            isTop = true;
            console.log(osTop - ispeed);
            if (osTop == 0) {
                clearInterval(timer);
            }
        }, 30);
    }

}
 
