window.onload = function () {
    var pics = document.getElementById("pics");
    var n = 1;
    setInterval(function () {
        if (n > 8) n = 1
        pics.innerHTML = "<img src='picture/big_pic_(" + n + ").png' />";
        n++;
    }, 1500);

    var roll_aa_pics = document.getElementById("roll_aa_pics");
    var j = 1;
    setInterval(function () {
        if (j > 3) j = 1
        roll_aa_pics.innerHTML = "<img src='picture/roll_aa_" + j + ".png' />";
        j++;
    }, 1500);

    var roll_bb_pics = document.getElementById("roll_bb_pics");
    var m = 1;
    setInterval(function () {
        if (m > 2) m = 1
        roll_bb_pics.innerHTML = "<img src='picture/roll_bb_" + m + ".png' />";
        m++;
    }, 1500);
    //鼠标悬停改变图片内容
    var item_1 = document.getElementById("item_1");
    item_1.onmouseenter = function(){
        item_1.children[0].setAttribute('src','picture/active_pic_' + 2 + '.png' )
    }
    item_1.onmouseleave = function(){
        item_1.children[0].setAttribute('src','picture/active_pic_' + 1 + '.png' )
    }

    var item_2 = document.getElementById("item_2");
    item_2.onmouseenter = function(){
        item_2.children[0].setAttribute('src','picture/active_pic_' + 4 + '.png' )
    }
    item_2.onmouseleave = function(){
        item_2.children[0].setAttribute('src','picture/active_pic_' + 3 + '.png' )
    }

    var item_3 = document.getElementById("item_3");
    item_3.onmouseenter = function(){
        item_3.children[0].setAttribute('src','picture/active_pic_' + 6 + '.png' )
    }
    item_3.onmouseleave = function(){
        item_3.children[0].setAttribute('src','picture/active_pic_' + 5 + '.png' )
    }

    var item_4 = document.getElementById("item_4");
    item_4.onmouseenter = function(){
        item_4.children[0].setAttribute('src','picture/active_pic_' + 8 + '.png' )
    }
    item_4.onmouseleave = function(){
        item_4.children[0].setAttribute('src','picture/active_pic_' + 7 + '.png' )
    }
    //倒计时
    var myVar;
    myVar = setInterval(countTime,1000);
    function countTime(){
        var date = new Date();
        var now = date.getTime();
        var str = "2019/9/10 00:00:00";
        var endDate = new Date(str);
        var end = endDate.getTime();
        var leftTime = end-now;
        var d,h,m,s;
        if (leftTime>=0){
            d = Math.floor(leftTime/1000/60/60/24);
            h = Math.floor(leftTime/1000/60/60%24);
            m = Math.floor(leftTime/1000/60%60);
            s = Math.floor(leftTime/1000%60);
        }
        document.getElementById("_d").innerHTML=d +"天";
        document.getElementById("_h").innerHTML=h +"时";
        document.getElementById("_m").innerHTML=m +"分";
        document.getElementById("_s").innerHTML=s +"秒";  
    }    
    var head_li = document.getElementById("head_li");
    var tab_content_aa = document.getElementById("tab_content_aa");
    var oli = head_li.getElementsByClassName("tabh");
    var otab = tab_content_aa.getElementsByClassName("content_tab");
    for(var i=0 ; i<oli.length ; i++){
        oli[i].index = i;
            oli[i].onmouseover = function(){
            for(var i =0; i < oli.length; i++)
             {
                oli[i].style.background = "#f5f5f5";
                oli[i].style.border= '0';
                otab[i].style.display = "none";
             }
            this.style.background = "#fff";
            this.style.border= '2px solid #000';
            this.style.borderBottom= '2px solid #fff';
            otab[this.index].style.display="block";
      }
    }
    var menulist_content = document.getElementById("menulist_content");
    var pop_tab = document.getElementById("pop_tab");
    var oli2 = menulist_content.getElementsByClassName("n_b");
    var otab2 = pop_tab.getElementsByClassName("new_pub_nav_pop");
    for(var i=0 ; i<oli2.length ; i++){
        oli2[i].index = i;
            oli2[i].onmouseenter = function(){
            for(var i =0; i < oli2.length; i++)
             {
                oli2[i].className = "n_b";
                otab2[i].style.display = "none";
             }
            this.className = "n_b on";
            otab2[this.index].style.display="block";
      }
    }
    for(var i=0 ; i<otab2.length ; i++){
        otab2[i].index = i;
            otab2[i].onmouseleave = function(){
            for(var i =0; i < otab2.length; i++)
             {
                oli2[i].className = "n_b";
                otab2[i].style.display = "none";
             }
            this.style.display="none";
            oli2[this.index].className="n_b";
      }
    }           
    //鼠标划过改变块内容
    var bb_1 =  document.getElementById("bb_1");
    var bb_2 =  document.getElementById("bb_2");    
    var content_tab_b1 = document.getElementById("content_tab_b1");
    var content_tab_b2 = document.getElementById("content_tab_b2");
    bb_1.onmouseover = function(){
        bb_1.style.background ='#fff';
        content_tab_b2.style.display = "none";
        content_tab_b1.style.display = "block";
    }
    bb_1.onmouseout = function(){
        bb_1.style.background = '#f5f5f5';
    }
    bb_2.onmouseover = function(){
        bb_2.style.background ='#fff';
        content_tab_b1.style.display = "none";
        content_tab_b2.style.display = "block";
    }
    bb_2.onmouseout = function(){
        bb_2.style.background = '#f5f5f5';
    }

    var list_cc = document.getElementById("list_cc");
    var oli3 = list_cc.getElementsByClassName("line bar");
    var otab3 = list_cc.getElementsByClassName("line item");
    for(var i=0 ; i<oli3.length ; i++){
        oli3[i].index = i;
            oli3[i].onmouseenter = function(){
            for(var i =0; i < oli3.length; i++)
             {
                oli3[i].className = "line bar ";
                otab3[i].style.display = "none";
             }
            this.className = "line bar hidden";
            otab3[this.index].style.display="block";
      }
    }
    var list_dd = document.getElementById("list_dd");
    var oli4 = list_dd.getElementsByClassName("line bar");
    var otab4 = list_dd.getElementsByClassName("line item");
    for(var i=0 ; i<oli4.length ; i++){
        oli4[i].index = i;
            oli4[i].onmouseenter = function(){
            for(var i =0; i < oli4.length; i++)
             {
                oli4[i].className = "line bar ";
                otab4[i].style.display = "none";
             }
            this.className = "line bar hidden";
            otab4[this.index].style.display="block";
      }
    }
    //鼠标划过改变块内容
    var xxgg = document.getElementById("xxgg");
    var fwgg = document.getElementById("fwgg");
    var xxgg_tab = document.getElementById("xxgg_tab");
    var fwgg_tab = document.getElementById("fwgg_tab");
    xxgg.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        xxgg_tab.style.display = 'block';
        fwgg_tab.style.display = 'none';
        xxgg.style.background = '#fff';
        fwgg.style.background = '#f0f0f0';
    }
    fwgg.onmouseover = function (e) {
        e = e || window.event;
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        fwgg_tab.style.display = 'block';
        xxgg_tab.style.display = 'none';
        fwgg.style.background = '#fff';
        xxgg.style.background = '#f0f0f0';
    }   
    //头部划过改变下拉菜单 
    var head_link_nav = document.getElementById("head_link_nav");
    var oli5 = head_link_nav.getElementsByClassName("menu_btn");
    var otab5 = head_link_nav.getElementsByClassName("gcard_list");
    for(var i=0 ; i<oli5.length ; i++){
        oli5[i].index = i;
            oli5[i].onmouseover = function(){
            for(var i =0; i < oli5.length; i++)
             {
                oli5[i].className="menu_btn"
                otab5[i].style.display = "none";
             }
             this.className="menu_btn hover"
            otab5[this.index].style.display= 'block';
      }
    }
    for(var i=0 ; i<oli5.length ; i++){
        oli5[i].index = i;
            oli5[i].onmouseleave = function(){
            for(var i =0; i < oli5.length; i++)
             {
                oli5[i].className="menu_btn"
                otab5[i].style.display = "none";
             }
             this.className="menu_btn"
            otab5[this.index].style.display= 'none';
      }
    }
    for(var i=0 ; i<otab5.length ; i++){
        otab5[i].index = i;
            otab5[i].onmouseleave = function(){
            for(var i =0; i < otab5.length; i++)
             {
                oli5[i].className = "menu_btn";
                otab5[i].style.display = "none";
             }
            this.style.display="none";
            oli5[this.index].className="menu_btn";
      }
    }  
    //鼠标划过背景改变
    var mydd_list = document.getElementById("mydd_list");
    var lis = mydd_list.getElementsByTagName('li');
    for (var i = 0, l = lis.length; i < l; i++) {
        lis[i].onmouseover = function (e) {
            e = e || window.event;
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
            this.style.background = '#e6e6e6';
        }
        lis[i].onmouseout = function () {
            this.style.background = '#FFF';
        }
    }
    var gouwu_list = document.getElementById("gouwu_list");
    var lis2 = gouwu_list.getElementsByTagName('li');
    for (var i = 0, l = lis2.length; i < l; i++) {
        lis2[i].onmouseover = function (e) {
            e = e || window.event;
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
            this.style.background = '#e6e6e6';
        }
        lis2[i].onmouseout = function () {
            this.style.background = '#FFF';
        }
    }
    var qycg_list = document.getElementById("qycg_list");
    var lis3 = qycg_list.getElementsByTagName('li');
    for (var i = 0, l = lis3.length; i < l; i++) {
        lis3[i].onmouseover = function (e) {
            e = e || window.event;
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
            this.style.background = '#e6e6e6';
        }
        lis3[i].onmouseout = function () {
            this.style.background = '#FFF';
        }
    }
    var khfw_list = document.getElementById("khfw_list");
    var lis4 = khfw_list.getElementsByTagName('li');
    for (var i = 0, l = lis4.length; i < l; i++) {
        lis4[i].onmouseover = function (e) {
            e = e || window.event;
            if (e.stopPropagation) {
                e.stopPropagation();
            } else {
                e.cancelBubble = true;
            }
            this.style.background = '#e6e6e6';
        }
        lis4[i].onmouseout = function () {
            this.style.background = '#FFF';
        }
    }
    //回到顶部//
    var obtn = document.getElementById("btn");
    var timer = null;
    var isTop = true;
    window.onscroll = function () {
        if (!isTop) {
            clearInterval(timer);
        }
        isTop = false;
    }
    obtn.onclick = function () {
        timer = setInterval(function(){
            var osTop = document.documentElement.scrollTop || document.body.scrollTop;
            var ispeed = Math.floor(-osTop / 6);
            document.documentElement.scrollTop = document.body.scrollTop = osTop + ispeed;
            isTop = true;
            console.log(osTop - ispeed);
            if (osTop == 0) {
                clearInterval(timer);
            }
        }, 30);
    }

}
 
